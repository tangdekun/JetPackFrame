package com.tdk.daggerdemo

/**
 * @Author tangdekun
 * @Date 2018/7/30-14:46
 * @Email tangdekun0924@gmail.com
 */
object Constant {
    val SHAREDPREFERENCES_FILE_NAME = "daggerdemo"
}