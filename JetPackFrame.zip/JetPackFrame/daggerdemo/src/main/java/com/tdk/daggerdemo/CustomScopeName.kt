package com.tdk.daggerdemo

import javax.inject.Scope

/**
 * @Author tangdekun
 * @Date 2018/7/30-16:13
 * @Email tangdekun0924@gmail.com
 */

@Scope
annotation class CustomScopeName