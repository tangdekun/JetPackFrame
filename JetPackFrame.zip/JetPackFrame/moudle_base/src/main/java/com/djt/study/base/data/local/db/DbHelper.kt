package com.djt.study.base.data.local.db

/**
 * @Author tangdekun
 * @Date 2018/8/2-15:10
 * @Email tangdekun0924@gmail.com
 */

interface DbHelper {

    /**
     * 参考demo  创建第一个函数时删除
     */

//    fun insertAppInfo(appInfoEntity: AppInfoEntity): Observable<Boolean>


}