package com.djt.study.base.data.local.sharedpreference

object PConstants {
    const val CLASS_NAME = "className"


}