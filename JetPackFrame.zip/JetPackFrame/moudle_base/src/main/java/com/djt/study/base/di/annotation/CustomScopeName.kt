package com.djt.study.base.di.annotation

/**
 * @Author tangdekun
 * @Date 2018/7/30-16:13
 * @Email tangdekun0924@gmail.com
 */
import javax.inject.Scope

@Scope
annotation class CustomScopeName