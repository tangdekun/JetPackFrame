package com.djt.study.base.data.remote

import javax.inject.Singleton

/**
 * @Author tangdekun
 * @Date 2018/7/30-14:27
 * @Email tangdekun0924@gmail.com
 */
@Singleton
interface ApiHelper {
    /**
     * 参考demo  创建第一个函数时删除
     */

//    fun gameRecommend(@Query("") userId: Int, @Query("userAge") age: Int, @Query("machineName") machineName: String): Observable<RecommendGame>
}