package com.djt.study.base.di.scope

import dagger.MapKey
import java.lang.annotation.Documented
import javax.inject.Scope
import javax.xml.transform.OutputKeys.METHOD

/**
 * Created by Glooory on 17/5/15.
 */
@Scope
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class ActivityScope


@Documented
@Target(METHOD)
@Retention(AnnotationRetention.RUNTIME)
@MapKey
public @interface ClassKey {
    Class<? > value();
}