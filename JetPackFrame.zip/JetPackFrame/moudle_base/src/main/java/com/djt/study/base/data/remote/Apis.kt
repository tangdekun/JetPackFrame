package com.djt.study.base.data.remote

/**
 * @Author tangdekun
 * @Date 2018/7/30-14:25
 * @Email tangdekun0924@gmail.com
 */
interface Apis {
    /**
     * 参考demo  创建第一个函数时删除
     */

//    @GET("LearnAnalysis/GameCommend")
//    fun gameRecommend(@Query("userId") userId: Int, @Query("userAge") stage: Int, @Query("machineName") machineName: String): Observable<RecommendGame>

}