package com.djt.study.base.data.local.sharedpreference

/**
 * @Author tangdekun
 * @Date 2018/8/2-15:42
 * @Email tangdekun0924@gmail.com
 */
interface PreferencesHelper {

}