package com.djt.study.base.di.scope

import javax.inject.Scope

/**
 * Created by GLooory on 17/5/15.
 */
@Scope
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class FragmentScope
