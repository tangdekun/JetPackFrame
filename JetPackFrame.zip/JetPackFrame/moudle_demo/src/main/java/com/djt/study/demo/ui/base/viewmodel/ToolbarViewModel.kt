package com.djt.study.demo.ui.base.viewmodel

import android.app.Application
import android.databinding.ObservableField
import android.databinding.ObservableInt
import android.view.View
import com.djt.mvvm.base.BaseViewModel
import com.djt.mvvm.binding.command.BindingAction
import com.djt.mvvm.binding.command.BindingCommand

/**
 * Create Author：goldze
 * Create Date：2019/01/03
 * Description： 对应include标题的ToolbarViewModel
 * Toolbar的封装方式有很多种，具体封装需根据项目实际业务和习惯来编写
 * 所有例子仅做参考,业务多种多样,可能我这里写的例子和你的需求不同，理解如何使用才最重要。
 */

class ToolbarViewModel(@NonNull application: Application) : BaseViewModel(application) {
    //标题文字
    var titleText: ObservableField<String> = ObservableField("")
    //右边文字
    var rightText: ObservableField<String> = ObservableField("更多")
    //右边文字的观察者
    var rightTextVisibleObservable = ObservableInt(View.GONE)
    //右边图标的观察者
    var rightIconVisibleObservable = ObservableInt(View.GONE)

    /**
     * 返回按钮的点击事件
     */
    val backOnClick = BindingCommand(object : BindingAction() {
        @Override
        fun call() {
            finish()
        }
    })

    var rightTextOnClick = BindingCommand(object : BindingAction() {
        @Override
        fun call() {
            rightTextOnClick()
        }
    })
    var rightIconOnClick = BindingCommand(object : BindingAction() {
        @Override
        fun call() {
            rightIconOnClick()
        }
    })

    /**
     * 设置标题
     *
     * @param text 标题文字
     */
    fun setTitleText(text: String) {
        titleText.set(text)
    }

    /**
     * 设置右边文字
     *
     * @param text 右边文字
     */
    fun setRightText(text: String) {
        rightText.set(text)
    }

    /**
     * 设置右边文字的显示和隐藏
     *
     * @param visibility
     */
    fun setRightTextVisible(visibility: Int) {
        rightTextVisibleObservable.set(visibility)
    }

    /**
     * 设置右边图标的显示和隐藏
     *
     * @param visibility
     */
    fun setRightIconVisible(visibility: Int) {
        rightIconVisibleObservable.set(visibility)
    }

    /**
     * 右边文字的点击事件，子类可重写
     */
    protected fun rightTextOnClick() {}

    /**
     * 右边图标的点击事件，子类可重写
     */
    protected fun rightIconOnClick() {}
}
